import java.awt.*;
import java.sql.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;

public class AWTDemo1 extends Frame implements ActionListener {
              /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
			/**
              * @param args
              */
              private JPanel pnlPerson;
              private JPanel pnlTitle;
              private JPanel pnlLang;
              private JPanel pnlInstr;
              private JPanel pnlBtn;
              private Label lblName;
              private Label lblPassword;
              private Label lblGender;
              private Label lblAge;
              private TextField tfName;
              private TextField tfPassword;
              private TextField tfQuery;
              private Checkbox cbMale;
              private Checkbox cbFemale;
              private CheckboxGroup cbg;
              private Choice chAge;
              private Checkbox cbJava;
              private Checkbox cbC;
              private Checkbox cbC1;
              private TextArea taInstr;
              private Button btnInsert;
              private Button btnUpdate;
              private Button btnDelete;
              private Button btnQuery;
              private JLabel lblTitle;
              private Connection connection;
              private Statement statement;
              private ResultSet rs;
              private Label lbresult;
              private String gender="Male";
              private String language="java";
              private String age="<1 year";

              GridBagConstraints c = new GridBagConstraints();
              public AWTDemo1(){
                           connToDb();
                           initializeComponents();
                           initializePanels();
                           registerListeners();
                           addComponentsToFrame();
                           pack();
                           addBorder();
                           setTitle("User Input Form");
                           setVisible(true);
                           setSize(600,700);
              }
              private void connToDb(){
                try {
                    Class.forName("oracle.jdbc.driver.OracleDriver");
                    connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","harry","harika");
                    statement = connection.createStatement();
              
                  } catch (SQLException connectException) {
                    System.out.println(connectException.getMessage());
                    System.out.println(connectException.getSQLState());
                    System.out.println(connectException.getErrorCode());
                    System.exit(1);
                  }
                  catch (Exception e) 
	             {
                      System.err.println("Unable to find and load driver");
                      System.exit(1);
                 }
              }
              private void initializeComponents(){
                           lblName=new Label("Name:");
                           lblPassword=new Label("Password:");
                           lblGender=new Label("Gender:");
                           lbresult=new Label("");
                           lblAge=new Label("Age:");
                           tfName=new TextField(5);
                           tfPassword=new TextField(5);
                           cbg = new CheckboxGroup();
                           cbMale=new Checkbox("Male",cbg,true);
                           cbFemale=new Checkbox("Female",cbg,false);
                           cbJava=new Checkbox("Java");
                           cbC=new Checkbox("C/C++");
                           cbC1=new Checkbox("C#");
                           chAge=new Choice();
                           btnInsert=new Button("Insert");
                           btnUpdate=new Button("Update");
                           btnDelete=new Button("Delete");
                           btnQuery=new Button("Query");
                           taInstr=new TextArea(10,50);
                           lblTitle=new JLabel("User Input Form");
                           lblTitle.setFont(new Font("User Input Form",Font.BOLD,20));
              }
              private void initializePanels() {
                           pnlPerson=new JPanel(new GridLayout(4,3));
                           pnlTitle=new JPanel(new BorderLayout());
                           pnlLang=new JPanel(new GridLayout(1,3));
                           pnlInstr=new JPanel(new GridLayout(1,1));
                           pnlBtn=new JPanel();
              }
              private void registerListeners(){
                cbMale.addItemListener(new ItemListener() {  
                    public void itemStateChanged(ItemEvent e) {
                      gender="Male";
                    }  
                 }); 
                cbFemale.addItemListener(new ItemListener() {  
                    public void itemStateChanged(ItemEvent e) {               
                      gender="Female";
                    }  
                 });  
                 cbJava.addItemListener(new ItemListener() {  
                  public void itemStateChanged(ItemEvent e) {               
                    language="java";
                  }  
               });
               cbC.addItemListener(new ItemListener() {  
                public void itemStateChanged(ItemEvent e) {  
                    language="C/C++"; 
                }  
             }); 
             cbC1.addItemListener(new ItemListener() {  
              public void itemStateChanged(ItemEvent e) {               
                language="C#";
              }  
              });

                           btnInsert.addActionListener(new ActionListener() {
                            public void actionPerformed(ActionEvent e) {
                                age=chAge.getItem(chAge.getSelectedIndex());
                              try {
                                Statement statement = connection.createStatement();
                                int i = statement
                                    .executeUpdate("insert into inputform values('"+tfName.getText() +"','"+tfPassword.getText()+"','"+gender+"','"+age+"','"+language+"')");
                                    lbresult.setText("inserted values success");
                                } catch (SQLException insertException) {
                                System.out.println("Error in insertion");
                              }
                            }
                          });
                           
                           btnDelete.addActionListener(new ActionListener() {
                            public void actionPerformed(ActionEvent e) {
                                age=chAge.getItem(chAge.getSelectedIndex());

                              try {
                                Statement statement = connection.createStatement();
                                int i = statement
                                    .executeUpdate("DELETE FROM inputform WHERE name = '"
                                        + tfName.getText()+"' and password='"+tfPassword.getText()+"'");
                              } catch (SQLException insertException) {
                                System.out.println("Error in deleting");
                              }
                            }
                          });

                           btnUpdate.addActionListener(new ActionListener() {
                            public void actionPerformed(ActionEvent e) {
                            age=chAge.getItem(chAge.getSelectedIndex());
                            try {
                          Statement statement = connection.createStatement();
                          int i = statement.executeUpdate(" update inputform set language='"+language+"' ,age='"+age+"',gender='"+gender+"' where name='"+tfName.getText()+"' and password='"+tfPassword.getText()+"'");
                            } catch (SQLException insertException) {
		                   System.out.println("Error in updating");
                            }
                          }
                        });

                           btnQuery.addActionListener(new ActionListener() {
                            public void actionPerformed(ActionEvent e) {
                                age=chAge.getItem(chAge.getSelectedIndex());
                              try {
                                Statement statement = connection.createStatement();
                                rs= statement.executeQuery(taInstr.getText());
                              } catch (SQLException insertException) {
                                 System.out.println("Error5");
                              }
                            }
                          });
                      
                           this.addWindowListener(new WindowAdapter(){
                                         public void windowClosing(WindowEvent e){
                                                       System.exit(0);
                                         }
                           });
              }
              private void addComponentsToFrame(){
                           chAge.add("< 1 year old");
                           chAge.add("2-10 years");
                           chAge.add("11-20 years");
                           chAge.add("21-30 years");
                           chAge.add("31-40 years");
                           chAge.add("41-50 years");
                           chAge.add("51-60 years");
                           chAge.add(">60 years");
                           pnlPerson.add(lblName);
                           pnlPerson.add(tfName);
                           pnlPerson.add(new Label(""));
                           pnlPerson.add(lblPassword);
                           pnlPerson.add(tfPassword);
                           pnlPerson.add(new Label(""));
                           pnlPerson.add(lblGender);
                           pnlPerson.add(cbMale);
                           pnlPerson.add(cbFemale);
                           pnlPerson.add(lblAge);
                           pnlPerson.add(chAge);
                           pnlLang.add(cbJava);
                           pnlLang.add(cbC);
                           pnlLang.add(cbC1);
                           pnlTitle.add(lblTitle);
                           pnlInstr.add(taInstr);
                           pnlBtn.add(btnInsert);
                           pnlBtn.add(btnUpdate);
                           pnlBtn.add(btnDelete);
                           pnlBtn.add(btnQuery);
                           pnlBtn.add(new Label(""));
                           pnlBtn.add(lbresult);
                           setLayout(new GridBagLayout());
                           c.fill = GridBagConstraints.HORIZONTAL;
                           c.gridx = 0;
                           c.gridy = 0;
                           add(pnlTitle,c);
                           c.gridx = 0;
                           c.gridy = 1;
                           add(pnlPerson,c);
                           c.gridx = 0;
                           c.gridy = 2;
                           add(pnlLang,c);
                           c.gridx = 0;
                           c.gridy = 3;
                           add(pnlInstr,c);
                           c.gridx = 0;
                           c.gridy = 4;
                           add(pnlBtn,c);
              }
              private void addBorder() {
                           Border blackline = BorderFactory.createLineBorder(Color.black);
                           TitledBorder title1=BorderFactory.createTitledBorder(blackline, "Person Particular");
                           pnlPerson.setBorder(title1);
                           title1=BorderFactory.createTitledBorder(blackline, "Languages");
                           pnlLang.setBorder(title1);
                           title1=BorderFactory.createTitledBorder(blackline, "Instruction");
                           pnlInstr.setBorder(title1);
              }
              public void actionPerformed(ActionEvent e){

                          

              }
              public static void main(String[] args) {
                           // TODO Auto-generated method stub
                           new AWTDemo1();
              }
}